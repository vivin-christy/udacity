## Log Analysis

This is the readme file for the Loganalysis project
#we will be using the script named loganalysis.py script to achive the below tasks the tasks the script does is finding the 1) most popular three articles 2) most popular article authors 3) On which days did more than 1% of requests lead to errors

$$ Technologies Used:
* Python 3
* PostgreSQL

## The Database consist of 3 tables as following:
  * The �authors� table includes information about the authors of articles.
  * The �articles� table includes the articles.
  * The �log� table includes one entry for each time a user has accessed the site indicates whether the request succeeded or failed.

##How to setup news database 
download the vagrant file to a folder
Then cd to that dir
$vagrent.exe up
Then you can ssh to the new vm
$vagrent.exe ssh
Then you need to install news database Download the news database as shown above Copy the file to the vagrant dir which was downloaded to boot vm then cd to the vagrant folder vagrent.exe ssh --> logon to vm cd to vagrant dir then run below comand to load data psql -d news -f newsdata.sql
Then we will use the script will connect to local pgsql db and fechtes the data. We used the python psycopg2 to achive this It achives the tasks in below ways


## The views used in this project:
  * The �articles_views� is used to have the articles and it's view count, created as following:
      ```
      CREATE OR REPLACE VIEW articles_views AS
             (SELECT slug as id, COUNT(path) AS views
             FROM articles
             LEFT JOIN log ON slug = substring(path from 10)
             GROUP BY slug);
      ```

## The project consist of 3 main functions as following:
  * The �get_top_articles� to get the top 3 articles in number of views.
  * The �get_top_authors� to get the authors ordered by the number of the views of their articles.
  * The �get_requests_fail_days� to get the days on which the requests lead to more than 1% errors.

## How to run the project:
  1. You should have the Postgresql installed on your machine download it from [here](https://www.postgresql.org/download/).
  2. You need to create a database and the 3 tables and the view download this [archieve]https://github.com/vivin-christy/udacity/newsdata.zip) extract the sql file which contains the statements for creating the tables then execute the create view statement.
  3. You need to have python 3 installed download from [here](https://www.python.org/downloads/).
  4. From the command line cd to the project location and run "python3 main.py".


#########How to use script By defaults it performs all tasks.. so run script as below vagrant@vagrant:~$ python main.py
########################### Candidate is jerk, alleges rival --- 338647 Bears love berries, alleges bear --- 253801 Bad things gone, say good people --- 170098
########################### Ursula La Multa --- 507594 Rudolf von Treppenwitz --- 423457 Anonymous Contributor --- 170098 Markoff Chaney --- 84557
########################### Jul 17,2016 --- 2.263 % errors
For a specific task you need to use below options
vagrant@vagrant:$ python main.py --popular3articles
########################### Candidate is jerk, alleges rival --- 338647 Bears love berries, alleges bear --- 253801 Bad things gone, say good people --- 170098
vagrant@vagrant:~$ python main.py --popularauthors
########################### Ursula La Multa --- 507594 Rudolf von Treppenwitz --- 423457 Anonymous Contributor --- 170098 Markoff Chaney --- 84557
vagrant@vagrant:~$ python main.py --errorrequests
########################### Jul 17,2016 --- 2.263 % errors

